# PHENIX: NULL EDEN - Pattern VFX Evolutions Manifest for Claude

Root folder: `pattern/`

## Non-negotiable generation rules
- Create one isolated image per VFX. Never make a grid/collage/contact sheet.
- No numbers, text, arrows, UI, frames, borders, labels, or watermarks inside the image.
- Background must be pure white or transparent. Transparent PNG is preferred for the game pipeline.
- Keep each VFX visually distinct. Do not reuse the same circular shape everywhere.
- Style: cyber aesthetic, neon glow, dynamic particles, readable silhouette, 3D depth, not flat.
- Recommended output per asset: 1024x1024 or 2048x2048 PNG, centered, enough padding, no cropped glow.

## Folder structure
```text
pattern/
  skeleton_cyber/
  taekwondo_girl/
  cyber_arm/
  brawler/
  assassin_clone_girl/
  euclid_vector_venom/
  oni/
  eddie/
  _by_pattern_type/   # optional duplicate/symlink organization, do not replace character folders
```

## Master placement table
| # | Character Folder | File Name | Evolution | Pattern | Silhouette |
|---:|---|---|---|---|---|
| 01 | `pattern/brawler/` | `pattern_01_vaporize_blade.png` | Vaporize Blade | Arc Slash | Μπροστινό ημικύκλιο 180 μοιρών |
| 02 | `pattern/euclid_vector_venom/` | `pattern_02_cryo_venom_fang.png` | Cryo Venom Fang | Lingering Cloud | Ακανόνιστο οργανικό σύννεφο ομίχλης |
| 03 | `pattern/taekwondo_girl/` | `pattern_03_absolute_zero_tempest.png` | Absolute Zero Tempest | Chain Lightning | Ζιγκ-ζαγκ σπασμένες γραμμές |
| 04 | `pattern/skeleton_cyber/` | `pattern_04_bloodfrost_guillotine.png` | Bloodfrost Guillotine | Mark + Detonate | Κάθετη, ευθεία γραμμή κρούσης |
| 06 | `pattern/eddie/` | `pattern_06_shatter_rift_blade.png` | Shatter Rift Blade | Ground Rift | Τεθλασμένες ρωγμές εδάφους |
| 07 | `pattern/assassin_clone_girl/` | `pattern_07_eclipse_frostfang.png` | Eclipse Frostfang | Summoned Echo Blades | Πολλαπλά διάσπαρτα lines κίνησης |
| 08 | `pattern/brawler/` | `pattern_08_caustic_inferno.png` | Caustic Inferno | Ground Rift | Πλατιά φλεγόμενη λωρίδα λάβας |
| 09 | `pattern/cyber_arm/` | `pattern_09_plasma_overload.png` | Plasma Overload | Chain Lightning | Ζιγκ-ζαγκ ηλεκτρικές γραμμές |
| 10 | `pattern/skeleton_cyber/` | `pattern_10_hellblood_cleaver.png` | Hellblood Cleaver | Arc Slash | Μπροστινό ημικύκλιο 180 μοιρών |
| 11 | `pattern/taekwondo_girl/` | `pattern_11_solar_flare_edge.png` | Solar Flare Edge | Orbiting Blades | Δακτύλιος σταθερής ακτίνας |
| 12 | `pattern/oni/` | `pattern_12_riftforge_blade.png` | Riftforge Blade | Ground Rift | Ακτινωτές ρωγμές εδάφους |
| 13 | `pattern/oni/` | `pattern_13_cinder_oblivion.png` | Cinder Oblivion | Lingering Cloud | Σκοτεινό ακανόνιστο σύννεφο καπνού |
| 14 | `pattern/euclid_vector_venom/` | `pattern_14_bio_shock_reaper.png` | Bio-Shock Reaper | Chain Lightning | Δίκτυο από ηλεκτρικά βιο-κυκλώματα |
| 15 | `pattern/euclid_vector_venom/` | `pattern_15_hemotoxin_fang.png` | Hemotoxin Fang | Lingering Cloud / Cyber Axe | Οργανική υγρή περιοχή DoT |
| 16 | `pattern/euclid_vector_venom/` | `pattern_16_nebula_blight.png` | Nebula Blight | Lingering Cloud / Cyber Axe | Κοσμικό νεφέλωμα χαμηλής βαρύτητας |
| 17 | `pattern/eddie/` | `pattern_17_plaguebringer.png` | Plaguebringer | Summoned Echo Blades / Cyber Axe | Αργές ημιδιαφανείς σφαίρες |
| 18 | `pattern/skeleton_cyber/` | `pattern_18_grave_rot_abyss.png` | Grave Rot Abyss | Lingering Cloud / Cyber Axe | Σκοτεινό πεδίο με κάθετες προεξοχές |
| 20 | `pattern/taekwondo_girl/` | `pattern_20_nova_circuit.png` | Nova Circuit | Orbiting Blades / Cyber Axe | Συνδεδεμένοι δακτύλιοι σε τροχιά |
| 21 | `pattern/cyber_arm/` | `pattern_21_stormrift_edge.png` | Stormrift Edge | Ground Rift / Cyber Axe | Απρόβλεπτες σκόρπιες ρωγμές |
| 22 | `pattern/assassin_clone_girl/` | `pattern_22_blackout_tempest.png` | Blackout Tempest | Lingering Cloud / Cyber Axe | Σκοτεινή καταιγίδα μεγάλης περιοχής |
| 23 | `pattern/brawler/` | `pattern_23_crimson_singularity.png` | Crimson Singularity | Pull + Burst / Cyber Axe | Δίνη που καταρρέει προς το κέντρο |
| 24 | `pattern/brawler/` | `pattern_24_ruin_halo.png` | Ruin Halo | Mark + Detonate / Cyber Axe | Δακτύλιος που διαστέλλεται |
| 25 | `pattern/assassin_clone_girl/` | `pattern_25_dread_reaver.png` | Dread Reaver | Arc Slash / Cyber Axe | Γρήγορα line trails και σκιώδη είδωλα |
| 26 | `pattern/cyber_arm/` | `pattern_26_event_horizon_blade.png` | Event Horizon Blade | Pull + Burst / Cyber Axe | Μαύρη τρύπα με ακτινωτές λόγχες |
| 27 | `pattern/eddie/` | `pattern_27_darkmatter_lance.png` | Darkmatter Lance | Wave Sweep / Cyber Axe | Πλατιά οριζόντια ζώνη ενέργειας |
| 28 | `pattern/oni/` | `pattern_28_null_eclipse.png` | Null Eclipse | Wave Sweep / Cyber Axe | Τεράστιος σταθερός σκοτεινός δίσκος |

## Character sections
### SKELETON CYBER
Νεκροζώντανος high-tech τρόμος: βαριά αιματηρά βιομηχανικά χτυπήματα και αποσύνθεση.

#### 04. Bloodfrost Guillotine
- Folder: `pattern/skeleton_cyber/`
- Filename: `pattern_04_bloodfrost_guillotine.png`
- Pattern: Mark + Detonate
- Silhouette: Κάθετη, ευθεία γραμμή κρούσης
- VFX: Φωτεινό κόκκινο/λευκό blood rune στο έδαφος. Από πάνω πέφτει κατακόρυφη λεπίδα γκιλοτίνας που σπάει σε κόκκινους κρυστάλλους και λευκή παγωμένη ομίχλη.

#### 10. Hellblood Cleaver
- Folder: `pattern/skeleton_cyber/`
- Filename: `pattern_10_hellblood_cleaver.png`
- Pattern: Arc Slash
- Silhouette: Μπροστινό ημικύκλιο 180 μοιρών
- VFX: Πλατιά βαριά ημικυκλική κοπή από κατακόκκινο ρευστό αίμα και φλόγες, με embers και μαύρο καπνό στις άκρες.

#### 18. Grave Rot Abyss
- Folder: `pattern/skeleton_cyber/`
- Filename: `pattern_18_grave_rot_abyss.png`
- Pattern: Lingering Cloud / Cyber Axe
- Silhouette: Σκοτεινό πεδίο με κάθετες προεξοχές
- VFX: Μαύρο miasma στο έδαφος, neon πράσινες κατακόρυφες ακίδες rot spikes και σκιώδη χέρια που βγαίνουν από το νέφος.

### TAEKWONDO GIRL
Ακροβατική μαχητής ταχύτητας: ηλεκτρικά loops και ενεργειακές τροχιές γύρω από τα λακτίσματα.

#### 03. Absolute Zero Tempest
- Folder: `pattern/taekwondo_girl/`
- Filename: `pattern_03_absolute_zero_tempest.png`
- Pattern: Chain Lightning
- Silhouette: Ζιγκ-ζαγκ σπασμένες γραμμές
- VFX: Λευκοί/κυανοί φουτουριστικοί κεραυνοί. Σε κάθε impact μικρό ice burst με παγοθραύσματα και sparks.

#### 11. Solar Flare Edge
- Folder: `pattern/taekwondo_girl/`
- Filename: `pattern_11_solar_flare_edge.png`
- Pattern: Orbiting Blades
- Silhouette: Δακτύλιος σταθερής ακτίνας
- VFX: Πορτοκαλί και κυανοί mini suns/plasma discs σε τέλειο κύκλο, με flare beams που πετάγονται προς τα έξω.

#### 20. Nova Circuit
- Folder: `pattern/taekwondo_girl/`
- Filename: `pattern_20_nova_circuit.png`
- Pattern: Orbiting Blades / Cyber Axe
- Silhouette: Συνδεδεμένοι δακτύλιοι σε τροχιά
- VFX: Ενεργειακοί κόμβοι σε κυκλική τροχιά, συνδεδεμένοι με σταθερά γαλάζια plasma beams σαν cyber ιστός.

### CYBER ARM
Βαρύς cyborg στρατιώτης: πλάσμα, ηλεκτρική υπερφόρτωση, rifts και κοσμικά pull/burst effects.

#### 09. Plasma Overload
- Folder: `pattern/cyber_arm/`
- Filename: `pattern_09_plasma_overload.png`
- Pattern: Chain Lightning
- Silhouette: Ζιγκ-ζαγκ ηλεκτρικές γραμμές
- VFX: Υπερφορτισμένοι κίτρινοι/πορτοκαλί κεραυνοί πλάσματος. Στις γωνίες δημιουργούνται μικρές ηλεκτρικές fire novas και sparks.

#### 21. Stormrift Edge
- Folder: `pattern/cyber_arm/`
- Filename: `pattern_21_stormrift_edge.png`
- Pattern: Ground Rift / Cyber Axe
- Silhouette: Απρόβλεπτες σκόρπιες ρωγμές
- VFX: Ακανόνιστες μωβ void rifts στον χώρο. Από μέσα ξεπηδούν ηλεκτρικές κοπές σε κίτρινο/λευκό.

#### 26. Event Horizon Blade
- Folder: `pattern/cyber_arm/`
- Filename: `pattern_26_event_horizon_blade.png`
- Pattern: Pull + Burst / Cyber Axe
- Silhouette: Μαύρη τρύπα με ακτινωτές λόγχες
- VFX: Μωβ/μαύρη τρύπα στο κέντρο που εκτοξεύει 360 μοιρών φωτεινές κυανές plasma lances.

### BRAWLER
Close-range brute force: μάγμα, shockwaves, rifts και βαριά screen-clear bursts.

#### 01. Vaporize Blade
- Folder: `pattern/brawler/`
- Filename: `pattern_01_vaporize_blade.png`
- Pattern: Arc Slash
- Silhouette: Μπροστινό ημικύκλιο 180 μοιρών
- VFX: Ημικυκλικό trail κοπής μισό λευκό/κυανό πάγο και μισό πορτοκαλί φωτιά, με πυκνό λευκογκρίζο ατμό στο κέντρο.

#### 08. Caustic Inferno
- Folder: `pattern/brawler/`
- Filename: `pattern_08_caustic_inferno.png`
- Pattern: Ground Rift
- Silhouette: Πλατιά φλεγόμενη λωρίδα λάβας
- VFX: Μεγάλη ρωγμή λάβας που βράζει σε πορτοκαλί χρώμα, με neon πράσινη acid corrosion στις άκρες και μαύρο καπνό.

#### 23. Crimson Singularity
- Folder: `pattern/brawler/`
- Filename: `pattern_23_crimson_singularity.png`
- Pattern: Pull + Burst / Cyber Axe
- Silhouette: Δίνη που καταρρέει προς το κέντρο
- VFX: Κόκκινη μαύρη τρύπα/vortex που έλκει σωματίδια και σκάει σε κυανή και κόκκινη plasma nova.

#### 24. Ruin Halo
- Folder: `pattern/brawler/`
- Filename: `pattern_24_ruin_halo.png`
- Pattern: Mark + Detonate / Cyber Axe
- Silhouette: Δακτύλιος που διαστέλλεται
- VFX: Σκοτεινός χαοτικός halo shockwave που διαστέλλεται απότομα με κατακόκκινους παλμούς και μωβ void αύρες.

### ASSASSIN CLONE GIRL
Stealth assassin: σκιές, κλώνοι, τυφλά χτυπήματα και τεχνητές καταιγίδες.

#### 07. Eclipse Frostfang
- Folder: `pattern/assassin_clone_girl/`
- Filename: `pattern_07_eclipse_frostfang.png`
- Pattern: Summoned Echo Blades
- Silhouette: Πολλαπλά διάσπαρτα lines κίνησης
- VFX: Ημιδιαφανή φαντάσματα σπαθιών σε μαύρο/λευκογκρίζο που κάνουν γρήγορα dashes και αφήνουν καπνό.

#### 22. Blackout Tempest
- Folder: `pattern/assassin_clone_girl/`
- Filename: `pattern_22_blackout_tempest.png`
- Pattern: Lingering Cloud / Cyber Axe
- Silhouette: Σκοτεινή καταιγίδα μεγάλης περιοχής
- VFX: Βαριά μαύρα σύννεφα καταιγίδας με τυχαίες εκτυφλωτικές λευκές λάμψεις κεραυνών μέσα στο νέφος.

#### 25. Dread Reaver
- Folder: `pattern/assassin_clone_girl/`
- Filename: `pattern_25_dread_reaver.png`
- Pattern: Arc Slash / Cyber Axe
- Silhouette: Γρήγορα line trails και σκιώδη είδωλα
- VFX: Κοφτερά σκιώδη trails κοπής σε μαύρο/κόκκινο, με μικρά terror sigils και afterimage smear.

### EUCLID VECTOR VENOM
Επιστήμονας DoT: γεωμετρικές ζώνες, οξέα, βιο-ηλεκτρικά δίκτυα και toxic control.

#### 02. Cryo Venom Fang
- Folder: `pattern/euclid_vector_venom/`
- Filename: `pattern_02_cryo_venom_fang.png`
- Pattern: Lingering Cloud
- Silhouette: Ακανόνιστο οργανικό σύννεφο ομίχλης
- VFX: Πράσινη τοξική παγωμένη ομίχλη, neon σταγόνες, κυανοί κρύσταλλοι πάγου και μικρές φυσαλίδες.

#### 14. Bio-Shock Reaper
- Folder: `pattern/euclid_vector_venom/`
- Filename: `pattern_14_bio_shock_reaper.png`
- Pattern: Chain Lightning
- Silhouette: Δίκτυο από ηλεκτρικά βιο-κυκλώματα
- VFX: Neon πράσινοι και κίτρινοι τοξικοί κεραυνοί που διακλαδίζονται σαν μολυσμένο bio-circuit grid.

#### 15. Hemotoxin Fang
- Folder: `pattern/euclid_vector_venom/`
- Filename: `pattern_15_hemotoxin_fang.png`
- Pattern: Lingering Cloud / Cyber Axe
- Silhouette: Οργανική υγρή περιοχή DoT
- VFX: Splatter zone με κατακόκκινο αίμα και neon πράσινες σταγόνες δηλητηρίου, υγρό και βαρύ.

#### 16. Nebula Blight
- Folder: `pattern/euclid_vector_venom/`
- Filename: `pattern_16_nebula_blight.png`
- Pattern: Lingering Cloud / Cyber Axe
- Silhouette: Κοσμικό νεφέλωμα χαμηλής βαρύτητας
- VFX: Ημιδιαφανές μωβ/πράσινο nebula cloud με διάσπαρτα φωτεινά plasma spores.

### ONI
Δαιμονικό ον: φωτιά του Άδη, χαοτική ενέργεια, ρήγματα και ολικές εκλείψεις.

#### 12. Riftforge Blade
- Folder: `pattern/oni/`
- Filename: `pattern_12_riftforge_blade.png`
- Pattern: Ground Rift
- Silhouette: Ακτινωτές ρωγμές εδάφους
- VFX: Ακτινωτές ρωγμές από τις οποίες πετάγονται κοφτερές λεπίδες μάγματος και μωβ void ενέργεια.

#### 13. Cinder Oblivion
- Folder: `pattern/oni/`
- Filename: `pattern_13_cinder_oblivion.png`
- Pattern: Lingering Cloud
- Silhouette: Σκοτεινό ακανόνιστο σύννεφο καπνού
- VFX: Περιοχή με κρύες μαύρες και στάχτινες φλόγες, καπνό και σωματίδια στάχτης.

#### 28. Null Eclipse
- Folder: `pattern/oni/`
- Filename: `pattern_28_null_eclipse.png`
- Pattern: Wave Sweep / Cyber Axe
- Silhouette: Τεράστιος σταθερός σκοτεινός δίσκος
- VFX: Γιγάντιος μαύρος δίσκος έκλειψης με φωτεινό μωβ void στεφάνι και micro-eruptions στο εσωτερικό.

### EDDIE
Μάγος κοσμικού κενού: σκοτεινή ύλη, void ρωγμές και μεγάλα ενεργειακά κύματα.

#### 06. Shatter Rift Blade
- Folder: `pattern/eddie/`
- Filename: `pattern_06_shatter_rift_blade.png`
- Pattern: Ground Rift
- Silhouette: Τεθλασμένες ρωγμές εδάφους
- VFX: Το έδαφος σκίζεται σε μωβ γραμμές και βγάζει ανάγλυφους λευκούς κρυστάλλους πάγου με black/violet void energy.

#### 17. Plaguebringer
- Folder: `pattern/eddie/`
- Filename: `pattern_17_plaguebringer.png`
- Pattern: Summoned Echo Blades / Cyber Axe
- Silhouette: Αργές ημιδιαφανείς σφαίρες
- VFX: Μωβ void orbs που κινούνται αργά και αφήνουν πράσινη τροχιά αποσύνθεσης.

#### 27. Darkmatter Lance
- Folder: `pattern/eddie/`
- Filename: `pattern_27_darkmatter_lance.png`
- Pattern: Wave Sweep / Cyber Axe
- Silhouette: Πλατιά οριζόντια ζώνη ενέργειας
- VFX: Τεράστιο οριζόντιο κύμα ημιδιαφανούς σκοτεινής ύλης με κυανά αστρικά σωματίδια.

## Claude execution contract
Generate assets in character order. After each generated asset, save it to the exact filename and folder shown above. If an asset comes out as a collage/grid, reject it and regenerate only that single asset.